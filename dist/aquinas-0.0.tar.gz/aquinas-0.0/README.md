Aquinas (**A** **qu**antum **in**terferometer **as**sembler) is a software package for transpiling linear interferometers into quantum circuits using a technique in the second quantization picture.
